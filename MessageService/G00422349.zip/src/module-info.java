/**
 * 
 */
/**
 * 
 */
module gmit.software {
	requires java.rmi;
	
	exports ie.atu.sw;
}